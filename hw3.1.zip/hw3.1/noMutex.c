#include <stdio.h> // For I/O operations
#include <pthread.h> // For thread operations
#include <unistd.h> // For sleep

#define MONEY_AVAILABLE 4000

// Global variable to store shirts left
int amountRemaining = MONEY_AVAILABLE;
int moneyTaken = 0;


void *studentA() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent= 4;
		char StudentID = 'A';
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent - 1) /Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
	}
}

void *studentB() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent= 4;
		char StudentID = 'B';
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent - 1) /Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
	}
}

void *studentC() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent= 4;
		char StudentID = 'C';
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent - 1) /Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
	}
}

int main () {

	printf("\nStarting with %d Dollars\n\n", MONEY_AVAILABLE);
	pthread_t threadA, threadB, threadC;

//	pthread_setconcurrency(3);

	pthread_create(&threadA, NULL, studentA, NULL);
	pthread_create(&threadB, NULL, studentB, NULL);
	pthread_create(&threadC, NULL, studentC, NULL);

	pthread_join(threadA, NULL);
	pthread_join(threadB, NULL);
	pthread_join(threadC, NULL);

	printf("\nTotal given out: %d Dollas.\n", moneyTaken);

	return 0;
}