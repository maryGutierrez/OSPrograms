#include <stdio.h> // For I/O operations
#include <pthread.h> // For thread operations
#include <unistd.h> // For sleep


#define MONEY_AVAILABLE 4000

// Global variable to store shirts left
int amountRemaining = MONEY_AVAILABLE;
int moneyTaken = 0;
pthread_mutex_t accessLock;


void *studentA() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent = 4;
		char StudentID = 'A';

		pthread_mutex_lock(&accessLock);
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent -1 ) / Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
		pthread_mutex_unlock(&accessLock);
	}
}

void *studentB() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent= 4;
		char StudentID = 'B';
		pthread_mutex_lock(&accessLock);
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent - 1) /Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
		pthread_mutex_unlock(&accessLock);
	}
}

void *studentC() {
	while (amountRemaining > 0) {
		// Fraction of pile this salesperson takes
		int Percent = 4;
		char StudentID = 'C';
		pthread_mutex_lock(&accessLock);
		// Ceiling divison
		int MoneyCount = (amountRemaining + Percent -1) / Percent;
		moneyTaken += MoneyCount;
		printf("%c = %d \n", StudentID, MoneyCount);
		amountRemaining -= MoneyCount;
//		sleep(1);
		pthread_mutex_unlock(&accessLock);
	}
}

int main () {

	printf("\nStarting with %d Dollars\n\n", MONEY_AVAILABLE);
	pthread_t threadA, threadB, threadC;

//	pthread_setconcurrency(3);

	pthread_create(&threadA, NULL, studentA, NULL);
	pthread_create(&threadB, NULL, studentB, NULL);
	pthread_create(&threadC, NULL, studentC, NULL);

	pthread_join(threadA, NULL);
	pthread_join(threadB, NULL);
	pthread_join(threadC, NULL);

	printf("\nTotal given out: %d Dollas.\n", moneyTaken);
//	printf("\n%d Dollars left.\n", amountRemaining);

	return 0;
}