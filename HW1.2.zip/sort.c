#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/** This program takes in several states names and organizes them Alphabetically. 
The program considers lowercase as smaller than uppercase.
 CTRL+D to stop input.
**/

int main() {
//
//	printf("\nEnter States to alphabetize. This program will output State names in  \n");
//	printf("alphabetical order with lowercase before uppercase. Press \"CTRL+D\" to end input\n");

	
	const int MAX_STATES = 12;
	const int MAX_CHAR = 20;
	char statesList[MAX_STATES][MAX_CHAR];
	int n = 0;

	// Take a list of names until CTRL+D
	while (!feof(stdin)) {
		scanf(" %s", statesList[n]);
		n++;
	}

	putc('\n', stdout);

	// condition for one item only
	if (n == 1) 
		printf("%s \n", statesList[0]);
	else {

		// set i to be the lowest val
		int i;
		for (i = 0; i < n; i++) {
			char tempWord[MAX_CHAR];

			int j;
			for (j = i + 1; j < (n - 1); j++) {

				int k;
				for (k = 0; k < MAX_CHAR; k++) {

					// subtract 90 from char to prioritize
					// the lowercase characters.
					bool leftLowerCase = false;
					bool rightLowerCase = false;
					if (statesList[i][k] > 96){
						statesList[i][k] -= 90;
						leftLowerCase = true;
					}
					if (statesList[j][k] > 96){
						statesList[j][k] -= 90;
						rightLowerCase = true;
					}
					if (statesList[i][k] == '\0'){
						if (leftLowerCase == true)
							statesList[i][k] += 90;
						if (rightLowerCase == true)
							statesList[j][k] += 90;
						break;
					}

					//set ascii back to lowercase if changed
					if (statesList[j][k] == '\0'){
						if (leftLowerCase == true)
							statesList[i][k] += 90;
						if (rightLowerCase == true)
							statesList[j][k] += 90;
						strcpy(tempWord, statesList[i]);
						strcpy(statesList[i], statesList[j]);
						strcpy(statesList[j], tempWord);
						break;					}

					if (statesList[i][k] < statesList[j][k]) {
						if (leftLowerCase == true)
							statesList[i][k] += 90;
						if (rightLowerCase == true)
							statesList[j][k] += 90;
						break;
					}
					else if (statesList[i][k] > statesList[j][k]) {	
						if (leftLowerCase == true)
							statesList[i][k] += 90;
						if (rightLowerCase == true)
							statesList[j][k] += 90;
						strcpy(tempWord, statesList[i]);
						strcpy(statesList[i], statesList[j]);
						strcpy(statesList[j], tempWord);
						break;
						}
					else {
						if (leftLowerCase == true)
							statesList[i][k] += 90;
						if (rightLowerCase == true)
							statesList[j][k] += 90;
						continue;
					}
				}
			}
		}
	}
	int j;
	for(j = 0; j < (n - 1); j++) {
		printf("%s \n", statesList[j]);
	}
	return 0;
}
