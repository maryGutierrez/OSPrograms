#include <stdio.h>

// This program runs a command through a forked child process

int main(int argc, char *argv[]) {

	// Create pid 
	int pid;
	pid = fork();

	// Create an array 

	if (pid < 0) {
		printf(stderr, "Fork FAILED");
		return -1;
	}
	else if (pid == 0) {
		printf("\nChild PID: %d    Parent PID: %d\n\n", getpid(), getppid());

		execvp(argv[1], argv+1);
	}
	else {
		wait(NULL);
	}

	return 0;
}