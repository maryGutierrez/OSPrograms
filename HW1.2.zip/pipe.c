#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
// The following program sets upp a child to parent pipe which connects to  perform 
// the sort proccess of the states 

int main() {
	
	char buf[20];
	int pid;
	int fd[2];
	
	//create pipe
	if (pipe(fd) == -1)
		printf("Pipe Not Created!");	
	
	//create child
	pid = fork();
	
	if (pid < 0) {
		printf("ERROR! CHILD NOT CREATED for some reason");
	}
	
	//parent reads from pipe
	else if (pid > 0) {	
		char *argv[] = {"sort", NULL}; 

		close(0);
		dup(fd[0]);
		close(fd[0]);
		close(fd[1]);

		if(execl(argv[0], argv, NULL) == -1)
			printf("FAILED\n\n");
	}
	
	//Child 
	else {
		char *argv[] = {"pre", NULL};

		close(1);
		dup(fd[1]);
		close(fd[1]);
		close(fd[0]);
		if(execl(argv[0], argv, NULL) == -1)
			printf("FAILED\n\n");
		printf("CHILD FINISHED");
	}
	
	
	return 0;
}