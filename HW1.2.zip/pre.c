#include <stdio.h>

/**
This program takes the abreviation and their populations
in one line. The program then outputs the names and population of each state over 10M
 CTRL+D, EOF, will stop the input.
**/

int main() {
	int Population[12];
	char USSTates[12][20];
	
	int i = 0;
//	printf("\nEnter State Name. \n");


	// Take name or abbreviation of the state and integer, add to respective arrays.
	while (!feof(stdin)) {
		scanf(" %s %d", USSTates[i], &Population[i]);
		i++;
	}
	
	int j = 0;
	
	putc('\n', stdout);
		
	// Iterate through each entry. If number is > 10 it will print the name
	while (j < (i - 1)) {
		if (Population[j] >10) {
			printf("%s \n", USSTates[j]);
		}
		j++;
	}
	
	return 0;
}
