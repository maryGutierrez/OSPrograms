#include <stdio.h>
#include <string.h>

// struct for state (name, population)
struct stateStruct {
	char state[3];
	int population;
};

// print method
void print(struct stateStruct ss[], int counter) {
    int i;
	for (i = 0; i < counter; i++) {
		printf("%s\n", ss[i].state);
	}
}

// main method
int main() {
	int size = 10;
	int counter = 0;
	int flag;
	struct stateStruct ss[size];
	char temp[3];

	int i;
	int j;

	// user input
	for (i = 0; i < size; i++) {
		flag = scanf("%s", ss[i].state);
		if (flag == EOF) {
			printf("\n");
			break;
		}
		counter++;
	}

	// sort
	for (i = 0; i < counter - 1; i++) {
		for (j = i + 1; j < counter; j++) {
			if (strcmp(ss[i].state, ss[j].state) > 0) {
				strcpy(temp, ss[i].state);
				strcpy(ss[i].state, ss[j].state);
				strcpy(ss[j].state, temp);
			}
		}
	}

	printf("\n");

	// print
	print(ss, counter);

	return 0;
}
