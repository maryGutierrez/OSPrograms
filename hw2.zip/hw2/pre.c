#include <stdio.h>

// struct
struct stateStruct {
	char state[3];
	int population;
};

// print greater than 10 million for population
void printGreaterThan10(struct stateStruct ss[], int counter) {
    int i;
	for (i = 0; i < counter; i++) {
		if (ss[i].population > 10) {
			printf("%s\n", ss[i].state);
		}
	}
}

// main
int main() {
	int size = 10;
	int counter = 0;
	int flag;
	struct stateStruct ss[size];

	int i;

	// user input
	for (i = 0; i < size; i++) {
		flag = scanf("%s %d", ss[i].state, &ss[i].population);
		if (flag == EOF) {
			printf("\n");
			break;
		}
		counter++;
	}

	printf("\n");

	// print
	printGreaterThan10(ss, counter);

	return 0;
}
